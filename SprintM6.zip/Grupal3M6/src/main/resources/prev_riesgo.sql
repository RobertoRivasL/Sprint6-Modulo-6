create database prev_riesgo;

