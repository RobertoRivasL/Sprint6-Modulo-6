package com.example.demo.utils;

public enum AuthorityName {
    CLIENTE,PROFESIONAL,ADMINISTRATIVO
}
